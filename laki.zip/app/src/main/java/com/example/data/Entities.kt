package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "drivers")
data class Driver(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val phone: String,
    val email: String,
    val password: String,
    val ktpPhoto: String, // Base64 representation or mock path
    val simPhoto: String, // Base64 representation or mock path
    val selfiePhoto: String, // Base64 representation or mock path (visible on profile)
    val vehiclePhoto: String, // Base64 representation or mock path (STNK)
    val status: String = "PENDING", // PENDING, APPROVED, REJECTED
    val bankAccount: String = "",
    val registeredAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "customers")
data class Customer(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val phone: String,
    val email: String,
    val password: String,
    val bankAccount: String = "",
    val registeredAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "admins")
data class Admin(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val email: String,
    val password: String,
    val bankAccount: String = "",
    val walletBalance: Double = 0.0
)

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val customerId: Int,
    val customerName: String,
    val customerPhone: String,
    val driverId: Int? = null,
    val driverName: String? = null,
    val driverPhone: String? = null,
    val pickupAddress: String,
    val deliveryAddress: String,
    val goodsType: String,
    val goodsWeight: Double,
    val recipientName: String,
    val recipientPhone: String,
    val status: String = "PENDING", // PENDING, ACCEPTED, AT_PICKUP, DELIVERED, COMPLETED, CANCELLED
    val distanceKm: Double,
    val totalFare: Double,
    val driverEarnings: Double,
    val adminCommission: Double,
    val pickupPhoto: String? = null,
    val deliveryPhoto: String? = null,
    val bankAccountCustomer: String = "",
    val bankAccountDriver: String = "",
    val bankAccountRecipient: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val acceptedAt: Long? = null,
    val completedAt: Long? = null
)
