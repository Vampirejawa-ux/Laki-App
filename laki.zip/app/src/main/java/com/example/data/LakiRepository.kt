package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class LakiRepository(
    private val driverDao: DriverDao,
    private val customerDao: CustomerDao,
    private val adminDao: AdminDao,
    private val orderDao: OrderDao
) {
    // Flows
    val allDrivers: Flow<List<Driver>> = driverDao.getAllDrivers()
    val allCustomers: Flow<List<Customer>> = customerDao.getAllCustomers()
    val allAdmins: Flow<List<Admin>> = adminDao.getAllAdmins()
    val allOrders: Flow<List<Order>> = orderDao.getAllOrders()

    fun getDriverById(id: Int): Flow<Driver?> = driverDao.getDriverById(id)
    fun getCustomerById(id: Int): Flow<Customer?> = customerDao.getCustomerById(id)
    fun getOrderById(id: Int): Flow<Order?> = orderDao.getOrderById(id)

    fun getOrdersByCustomerId(customerId: Int): Flow<List<Order>> =
        orderDao.getOrdersByCustomerId(customerId)

    fun getOrdersByDriverId(driverId: Int): Flow<List<Order>> =
        orderDao.getOrdersByDriverId(driverId)

    // Validation for unique registration (no duplicate phone/email in either role)
    suspend fun isDataUnique(phone: String, email: String): Boolean {
        val trimmedPhone = phone.trim()
        val trimmedEmail = email.trim()

        val driverByPhone = driverDao.getDriverByPhone(trimmedPhone)
        val driverByEmail = driverDao.getDriverByEmail(trimmedEmail)
        val customerByPhone = customerDao.getCustomerByPhone(trimmedPhone)
        val customerByEmail = customerDao.getCustomerByEmail(trimmedEmail)

        return (driverByPhone == null && driverByEmail == null &&
                customerByPhone == null && customerByEmail == null)
    }

    // Driver Operations
    suspend fun registerDriver(driver: Driver): Boolean {
        if (!isDataUnique(driver.phone, driver.email)) {
            return false
        }
        driverDao.insertDriver(driver)
        return true
    }

    suspend fun loginDriver(phoneOrEmail: String, password: String): Driver? {
        val trimmed = phoneOrEmail.trim()
        val driver = driverDao.getDriverByPhone(trimmed) ?: driverDao.getDriverByEmail(trimmed)
        return if (driver != null && driver.password == password) driver else null
    }

    suspend fun updateDriver(driver: Driver) {
        driverDao.updateDriver(driver)
    }

    // Customer Operations
    suspend fun registerCustomer(customer: Customer): Boolean {
        if (!isDataUnique(customer.phone, customer.email)) {
            return false
        }
        customerDao.insertCustomer(customer)
        return true
    }

    suspend fun loginCustomer(phoneOrEmail: String, password: String): Customer? {
        val trimmed = phoneOrEmail.trim()
        val customer = customerDao.getCustomerByPhone(trimmed) ?: customerDao.getCustomerByEmail(trimmed)
        return if (customer != null && customer.password == password) customer else null
    }

    // Admin Operations
    suspend fun registerAdmin(admin: Admin): Boolean {
        // Enforce max 2 admins limit
        val existingAdmins = allAdmins.firstOrNull() ?: emptyList()
        if (existingAdmins.size >= 2) {
            return false
        }
        // Unique email check
        val adminByEmail = adminDao.getAdminByEmail(admin.email.trim())
        if (adminByEmail != null) {
            return false
        }
        adminDao.insertAdmin(admin)
        return true
    }

    suspend fun loginAdmin(email: String, password: String): Admin? {
        val admin = adminDao.getAdminByEmail(email.trim())
        return if (admin != null && admin.password == password) admin else null
    }

    suspend fun updateAdmin(admin: Admin) {
        adminDao.updateAdmin(admin)
    }

    // Order Operations
    suspend fun placeOrder(
        customerId: Int,
        customerName: String,
        customerPhone: String,
        pickupAddress: String,
        deliveryAddress: String,
        goodsType: String,
        goodsWeight: Double,
        recipientName: String,
        recipientPhone: String,
        distanceKm: Double,
        bankAccountCustomer: String = "",
        bankAccountRecipient: String = ""
    ): Long {
        // Calculate fare: Rp 3000/KM, add Rp 5000 if weight > 25KG
        val baseFare = distanceKm * 3000.0
        val surcharge = if (goodsWeight > 25.0) 5000.0 else 0.0
        val totalFare = baseFare + surcharge
        val adminCommission = totalFare * 0.08
        val driverEarnings = totalFare - adminCommission

        val order = Order(
            customerId = customerId,
            customerName = customerName,
            customerPhone = customerPhone,
            pickupAddress = pickupAddress,
            deliveryAddress = deliveryAddress,
            goodsType = goodsType,
            goodsWeight = goodsWeight,
            recipientName = recipientName,
            recipientPhone = recipientPhone,
            distanceKm = distanceKm,
            totalFare = totalFare,
            driverEarnings = driverEarnings,
            adminCommission = adminCommission,
            status = "PENDING",
            bankAccountCustomer = bankAccountCustomer,
            bankAccountRecipient = bankAccountRecipient
        )
        return orderDao.insertOrder(order)
    }

    suspend fun cancelOrder(orderId: Int) {
        val order = orderDao.getOrderByIdSync(orderId)
        if (order != null) {
            orderDao.updateOrder(order.copy(status = "CANCELLED"))
        }
    }

    suspend fun acceptOrder(orderId: Int, driverId: Int, driverName: String, driverPhone: String, bankAccountDriver: String) {
        val order = orderDao.getOrderByIdSync(orderId)
        if (order != null) {
            orderDao.updateOrder(order.copy(
                status = "ACCEPTED",
                driverId = driverId,
                driverName = driverName,
                driverPhone = driverPhone,
                bankAccountDriver = bankAccountDriver,
                acceptedAt = System.currentTimeMillis()
            ))
        }
    }

    suspend fun updateOrderToAtPickup(orderId: Int, pickupPhoto: String) {
        val order = orderDao.getOrderByIdSync(orderId)
        if (order != null) {
            orderDao.updateOrder(order.copy(
                status = "AT_PICKUP",
                pickupPhoto = pickupPhoto
            ))
        }
    }

    suspend fun updateOrderToDelivered(orderId: Int, deliveryPhoto: String, finalRecipientName: String) {
        val order = orderDao.getOrderByIdSync(orderId)
        if (order != null) {
            orderDao.updateOrder(order.copy(
                status = "DELIVERED",
                deliveryPhoto = deliveryPhoto,
                recipientName = finalRecipientName
            ))
        }
    }

    suspend fun completeOrder(orderId: Int) {
        val order = orderDao.getOrderByIdSync(orderId)
        if (order != null && order.status != "COMPLETED") {
            // Update order status
            orderDao.updateOrder(order.copy(
                status = "COMPLETED",
                completedAt = System.currentTimeMillis()
            ))

            // Deposit 8% commission to all registered admins' wallets
            val admins = allAdmins.firstOrNull() ?: emptyList()
            for (admin in admins) {
                adminDao.updateAdmin(admin.copy(
                    walletBalance = admin.walletBalance + order.adminCommission
                ))
            }
        }
    }

    suspend fun adminWithdraw(adminId: Int, amount: Double): Boolean {
        val admins = allAdmins.firstOrNull() ?: emptyList()
        val admin = admins.find { it.id == adminId } ?: return false
        if (admin.walletBalance >= amount && amount > 0) {
            adminDao.updateAdmin(admin.copy(
                walletBalance = admin.walletBalance - amount
            ))
            return true
        }
        return false
    }
}
