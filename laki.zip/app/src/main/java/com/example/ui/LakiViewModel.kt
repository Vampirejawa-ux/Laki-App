package com.example.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Admin
import com.example.data.AppDatabase
import com.example.data.Customer
import com.example.data.Driver
import com.example.data.LakiRepository
import com.example.data.Order
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

enum class LakiScreen {
    Home,
    CustomerRegister,
    CustomerLogin,
    CustomerDashboard,
    CustomerOrderForm,
    CustomerActiveOrderTracking,
    DriverRegister,
    DriverLogin,
    DriverDashboard,
    DriverWhatsappSimulator,
    AdminRegister,
    AdminLogin,
    AdminDashboard
}

class LakiViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getDatabase(application)
    private val repository = LakiRepository(
        driverDao = database.driverDao(),
        customerDao = database.customerDao(),
        adminDao = database.adminDao(),
        orderDao = database.orderDao()
    )

    // Navigation State
    var currentScreen by mutableStateOf(LakiScreen.Home)
        private set

    fun navigateTo(screen: LakiScreen) {
        clearMessages()
        currentScreen = screen
    }

    // User Session States
    var loggedInCustomer by mutableStateOf<Customer?>(null)
        private set
    var loggedInDriver by mutableStateOf<Driver?>(null)
        private set
    var loggedInAdmin by mutableStateOf<Admin?>(null)
        private set

    // Status Messages
    var errorMessage by mutableStateOf<String?>(null)
        private set
    var successMessage by mutableStateOf<String?>(null)
        private set

    fun clearMessages() {
        errorMessage = null
        successMessage = null
    }

    // Reactive database lists for UI
    val allDrivers: StateFlow<List<Driver>> = repository.allDrivers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCustomers: StateFlow<List<Customer>> = repository.allCustomers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allAdmins: StateFlow<List<Admin>> = repository.allAdmins
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allOrders: StateFlow<List<Order>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active order flow state
    var selectedOrderForTracking by mutableStateOf<Order?>(null)
        private set

    // Customer Registration
    fun registerCustomer(customer: Customer) {
        viewModelScope.launch {
            clearMessages()
            if (customer.name.isBlank() || customer.phone.isBlank() || customer.email.isBlank() || customer.password.isBlank()) {
                errorMessage = "Semua data wajib diisi!"
                return@launch
            }
            val success = repository.registerCustomer(customer)
            if (success) {
                successMessage = "Registrasi Customer berhasil! Silakan login."
                navigateTo(LakiScreen.CustomerLogin)
            } else {
                errorMessage = "Registrasi gagal! Nomor HP atau email sudah terdaftar sebagai Driver atau Customer."
            }
        }
    }

    // Customer Login
    fun loginCustomer(phoneOrEmail: String, password: String) {
        viewModelScope.launch {
            clearMessages()
            if (phoneOrEmail.isBlank() || password.isBlank()) {
                errorMessage = "Harap masukkan nomor HP/email dan password."
                return@launch
            }
            val customer = repository.loginCustomer(phoneOrEmail, password)
            if (customer != null) {
                loggedInCustomer = customer
                successMessage = "Selamat datang, ${customer.name}!"
                navigateTo(LakiScreen.CustomerDashboard)
            } else {
                errorMessage = "Nomor HP/Email atau Password salah."
            }
        }
    }

    fun logoutCustomer() {
        loggedInCustomer = null
        navigateTo(LakiScreen.Home)
    }

    // Driver Registration
    fun registerDriver(driver: Driver) {
        viewModelScope.launch {
            clearMessages()
            if (driver.name.isBlank() || driver.phone.isBlank() || driver.email.isBlank() || driver.password.isBlank()) {
                errorMessage = "Semua data wajib diisi!"
                return@launch
            }
            if (driver.ktpPhoto.isBlank() || driver.simPhoto.isBlank() || driver.selfiePhoto.isBlank() || driver.vehiclePhoto.isBlank()) {
                errorMessage = "Harap lampirkan semua foto yang diwajibkan (KTP, SIM, Selfie, STNK)."
                return@launch
            }
            val success = repository.registerDriver(driver)
            if (success) {
                successMessage = "Pendaftaran Driver berhasil! Menunggu persetujuan Admin."
                navigateTo(LakiScreen.DriverLogin)
            } else {
                errorMessage = "Registrasi gagal! Nomor HP atau email sudah terdaftar sebagai Customer atau Driver."
            }
        }
    }

    // Driver Login
    fun loginDriver(phoneOrEmail: String, password: String) {
        viewModelScope.launch {
            clearMessages()
            if (phoneOrEmail.isBlank() || password.isBlank()) {
                errorMessage = "Harap masukkan nomor HP/email dan password."
                return@launch
            }
            val driver = repository.loginDriver(phoneOrEmail, password)
            if (driver != null) {
                if (driver.status == "PENDING") {
                    errorMessage = "Akun Driver Anda masih PENDING. Harap tunggu persetujuan Admin."
                } else if (driver.status == "REJECTED") {
                    errorMessage = "Pengajuan akun Driver Anda DITOLAK oleh Admin."
                } else {
                    loggedInDriver = driver
                    successMessage = "Selamat datang Driver, ${driver.name}!"
                    navigateTo(LakiScreen.DriverDashboard)
                }
            } else {
                errorMessage = "Nomor HP/Email atau Password salah."
            }
        }
    }

    fun logoutDriver() {
        loggedInDriver = null
        navigateTo(LakiScreen.Home)
    }

    // Admin Registration (Max 2 admins limit)
    fun registerAdmin(admin: Admin) {
        viewModelScope.launch {
            clearMessages()
            if (admin.name.isBlank() || admin.email.isBlank() || admin.password.isBlank()) {
                errorMessage = "Semua data wajib diisi!"
                return@launch
            }
            val success = repository.registerAdmin(admin)
            if (success) {
                successMessage = "Registrasi Admin berhasil! Silakan login."
                navigateTo(LakiScreen.AdminLogin)
            } else {
                errorMessage = "Registrasi Admin gagal! Maksimal 2 admin diperbolehkan atau email sudah terdaftar."
            }
        }
    }

    // Admin Login
    fun loginAdmin(email: String, password: String) {
        viewModelScope.launch {
            clearMessages()
            if (email.isBlank() || password.isBlank()) {
                errorMessage = "Harap masukkan email dan password."
                return@launch
            }
            val admin = repository.loginAdmin(email, password)
            if (admin != null) {
                loggedInAdmin = admin
                successMessage = "Selamat datang Admin, ${admin.name}!"
                navigateTo(LakiScreen.AdminDashboard)
            } else {
                errorMessage = "Email atau Password Admin salah."
            }
        }
    }

    fun logoutAdmin() {
        loggedInAdmin = null
        navigateTo(LakiScreen.Home)
    }

    // Admin approve/reject driver
    fun setDriverStatus(driverId: Int, newStatus: String) {
        viewModelScope.launch {
            val drivers = allDrivers.value
            val driver = drivers.find { it.id == driverId }
            if (driver != null) {
                val updated = driver.copy(status = newStatus)
                repository.updateDriver(updated)
                successMessage = "Status driver ${driver.name} diubah menjadi $newStatus."
            }
        }
    }

    // Admin withdrawal
    fun withdrawAdminWallet(amount: Double, bankAccount: String) {
        viewModelScope.launch {
            clearMessages()
            val currentAdminId = loggedInAdmin?.id ?: return@launch
            if (amount <= 0) {
                errorMessage = "Masukkan nominal penarikan yang valid."
                return@launch
            }
            if (bankAccount.isBlank()) {
                errorMessage = "Rekening penarikan harus diisi."
                return@launch
            }
            val success = repository.adminWithdraw(currentAdminId, amount)
            if (success) {
                // Refresh local admin session balance
                val admins = repository.allAdmins.firstOrNull() ?: emptyList()
                loggedInAdmin = admins.find { it.id == currentAdminId }
                successMessage = "Penarikan sebesar Rp $amount ke rekening $bankAccount berhasil diproses!"
            } else {
                errorMessage = "Saldo wallet admin tidak mencukupi."
            }
        }
    }

    // Customer places order
    fun submitOrder(
        pickupAddress: String,
        deliveryAddress: String,
        goodsType: String,
        goodsWeight: Double,
        customerPhone: String,
        recipientPhone: String,
        recipientName: String,
        distanceKm: Double,
        bankAccountCustomer: String,
        bankAccountRecipient: String
    ) {
        viewModelScope.launch {
            clearMessages()
            val customer = loggedInCustomer ?: return@launch
            if (pickupAddress.isBlank() || deliveryAddress.isBlank() || goodsType.isBlank() || recipientName.isBlank() || recipientPhone.isBlank()) {
                errorMessage = "Semua detail order harus diisi!"
                return@launch
            }
            if (customerPhone.isBlank()) {
                errorMessage = "Nomor HP Customer yang aktif wajib diisi!"
                return@launch
            }

            // Radius check: Maximum 5 KM from driver.
            // If simulated distance is > 5 KM, order cannot be placed!
            if (distanceKm > 5.0) {
                errorMessage = "Maaf, alamat pengambilan di luar radius layanan maksimal (5 KM dari Driver terdekat). Sistem tidak menemukan driver."
                return@launch
            }

            // Find an approved driver to simulate sending WhatsApp to
            val approvedDrivers = allDrivers.value.filter { it.status == "APPROVED" }
            if (approvedDrivers.isEmpty()) {
                errorMessage = "Tidak ada driver yang aktif/disetujui admin untuk mengambil order saat ini."
                return@launch
            }

            // Place the order
            val orderId = repository.placeOrder(
                customerId = customer.id,
                customerName = customer.name,
                customerPhone = customerPhone,
                pickupAddress = pickupAddress,
                deliveryAddress = deliveryAddress,
                goodsType = goodsType,
                goodsWeight = goodsWeight,
                recipientName = recipientName,
                recipientPhone = recipientPhone,
                distanceKm = distanceKm,
                bankAccountCustomer = bankAccountCustomer,
                bankAccountRecipient = bankAccountRecipient
            )

            // Select order for tracking and navigate
            val ordersList = repository.allOrders.firstOrNull() ?: emptyList()
            val createdOrder = ordersList.find { it.id == orderId.toInt() }
            selectedOrderForTracking = createdOrder

            successMessage = "Order berhasil dipesan! Detil order langsung terkirim ke WhatsApp Driver terdekat."
            navigateTo(LakiScreen.CustomerActiveOrderTracking)
        }
    }

    // Driver WhatsApp Actions
    fun driverAcceptOrder(orderId: Int) {
        viewModelScope.launch {
            clearMessages()
            val driver = loggedInDriver ?: return@launch
            repository.acceptOrder(
                orderId = orderId,
                driverId = driver.id,
                driverName = driver.name,
                driverPhone = driver.phone,
                bankAccountDriver = driver.bankAccount
            )
            // Refresh local selected tracking order
            val ordersList = repository.allOrders.firstOrNull() ?: emptyList()
            selectedOrderForTracking = ordersList.find { it.id == orderId }
            successMessage = "Anda telah mengambil orderan! Detail pengambilan paket & tarif bersih telah ditampilkan."
        }
    }

    fun driverCancelOrder(orderId: Int) {
        viewModelScope.launch {
            clearMessages()
            repository.cancelOrder(orderId)
            val ordersList = repository.allOrders.firstOrNull() ?: emptyList()
            selectedOrderForTracking = ordersList.find { it.id == orderId }
            successMessage = "Orderan berhasil dibatalkan."
        }
    }

    // Driver takes photo of package during pickup
    fun driverConfirmPickup(orderId: Int, pickupPhotoBase64: String) {
        viewModelScope.launch {
            clearMessages()
            if (pickupPhotoBase64.isBlank()) {
                errorMessage = "Wajib mengambil foto paket sebelum melanjutkan!"
                return@launch
            }
            repository.updateOrderToAtPickup(orderId, pickupPhotoBase64)
            val ordersList = repository.allOrders.firstOrNull() ?: emptyList()
            selectedOrderForTracking = ordersList.find { it.id == orderId }
            successMessage = "Foto paket terkirim otomatis ke WhatsApp Customer! Status: Dalam Pengiriman."
        }
    }

    // Driver takes photo of package and inputs recipient's name during delivery
    fun driverConfirmDelivery(orderId: Int, deliveryPhotoBase64: String, finalRecipientName: String) {
        viewModelScope.launch {
            clearMessages()
            if (deliveryPhotoBase64.isBlank()) {
                errorMessage = "Wajib mengambil foto paket saat sampai di alamat pengantaran!"
                return@launch
            }
            if (finalRecipientName.isBlank()) {
                errorMessage = "Harap isi nama penerima paket!"
                return@launch
            }
            repository.updateOrderToDelivered(orderId, deliveryPhotoBase64, finalRecipientName)
            val ordersList = repository.allOrders.firstOrNull() ?: emptyList()
            selectedOrderForTracking = ordersList.find { it.id == orderId }
            successMessage = "Foto paket terkirim otomatis ke WhatsApp Penerima! Menunggu konfirmasi pembayaran."
        }
    }

    // Complete the transaction
    fun driverCompleteOrder(orderId: Int) {
        viewModelScope.launch {
            clearMessages()
            repository.completeOrder(orderId)
            val ordersList = repository.allOrders.firstOrNull() ?: emptyList()
            selectedOrderForTracking = ordersList.find { it.id == orderId }

            // Refresh admin session just in case they are logged in and looking at balance
            loggedInAdmin?.let { currentAdmin ->
                val admins = repository.allAdmins.firstOrNull() ?: emptyList()
                loggedInAdmin = admins.find { it.id == currentAdmin.id }
            }

            successMessage = "Transaksi selesai! Pembayaran diterima dan potongan komisi 8% telah disalurkan ke Wallet Admin."
        }
    }

    // Helper statistics functions
    fun getDriverEarningsStats(driverId: Int): DriverEarningsStats {
        val completedOrders = allOrders.value.filter { it.driverId == driverId && it.status == "COMPLETED" }

        val todayStart = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val weekStart = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -7)
        }.timeInMillis

        val monthStart = Calendar.getInstance().apply {
            add(Calendar.DAY_OF_YEAR, -30)
        }.timeInMillis

        val daily = completedOrders.filter { it.completedAt ?: 0 >= todayStart }.sumOf { it.driverEarnings }
        val weekly = completedOrders.filter { it.completedAt ?: 0 >= weekStart }.sumOf { it.driverEarnings }
        val monthly = completedOrders.filter { it.completedAt ?: 0 >= monthStart }.sumOf { it.driverEarnings }

        return DriverEarningsStats(daily, weekly, monthly, completedOrders)
    }

    fun selectOrderForTracking(order: Order) {
        selectedOrderForTracking = order
    }
}

data class DriverEarningsStats(
    val daily: Double,
    val weekly: Double,
    val monthly: Double,
    val completedOrders: List<Order>
)
