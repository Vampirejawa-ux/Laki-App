package com.example.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.Admin
import com.example.data.Customer
import com.example.data.Driver
import com.example.data.Order
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Custom Colors for Laki App Theme (Energetic Amber, Orange & Slate Blue Dark)
val LakiPrimary = Color(0xFFFF9F1C)     // Vibrant Orange
val LakiSecondary = Color(0xFF2EC4B6)   // Teal Accent
val LakiBackground = Color(0xFF0F172A)  // Deep Navy slate
val LakiSurface = Color(0xFF1E293B)     // Light Slate card
val LakiTextLight = Color(0xFFF8FAFC)
val LakiTextMuted = Color(0xFF94A3B8)
val WhatsAppGreen = Color(0xFF25D366)
val WhatsAppChatBg = Color(0xFFECE5DD)
val WhatsAppChatBgDark = Color(0xFF0B141A)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LakiApp(viewModel: LakiViewModel) {
    val context = LocalContext.current
    val currentScreen = viewModel.currentScreen

    val drivers by viewModel.allDrivers.collectAsStateWithLifecycle()
    val customers by viewModel.allCustomers.collectAsStateWithLifecycle()
    val admins by viewModel.allAdmins.collectAsStateWithLifecycle()
    val orders by viewModel.allOrders.collectAsStateWithLifecycle()

    val errorMessage = viewModel.errorMessage
    val successMessage = viewModel.successMessage

    // Display Toast notifications when messages are updated
    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
        }
    }
    LaunchedEffect(successMessage) {
        successMessage?.let {
            Toast.makeText(context, it, Toast.LENGTH_LONG).show()
        }
    }

    Scaffold(
        topBar = {
            if (currentScreen != LakiScreen.Home) {
                TopAppBar(
                    title = {
                        Text(
                            text = when (currentScreen) {
                                LakiScreen.CustomerRegister -> "Daftar Customer"
                                LakiScreen.CustomerLogin -> "Login Customer"
                                LakiScreen.CustomerDashboard -> "Dasbor Customer"
                                LakiScreen.CustomerOrderForm -> "Pesan Layanan Laki"
                                LakiScreen.CustomerActiveOrderTracking -> "Traking Pengiriman"
                                LakiScreen.DriverRegister -> "Gabung Jadi Driver"
                                LakiScreen.DriverLogin -> "Login Driver"
                                LakiScreen.DriverDashboard -> "Dasbor Driver"
                                LakiScreen.DriverWhatsappSimulator -> "WhatsApp Laki-Simulator"
                                LakiScreen.AdminRegister -> "Daftar Admin"
                                LakiScreen.AdminLogin -> "Login Admin"
                                LakiScreen.AdminDashboard -> "Dasbor Admin"
                                else -> "Laki"
                            },
                            fontWeight = FontWeight.Bold,
                            color = LakiTextLight
                        )
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            when (currentScreen) {
                                LakiScreen.CustomerDashboard -> viewModel.logoutCustomer()
                                LakiScreen.DriverDashboard -> viewModel.logoutDriver()
                                LakiScreen.AdminDashboard -> viewModel.logoutAdmin()
                                LakiScreen.CustomerOrderForm, LakiScreen.CustomerActiveOrderTracking -> viewModel.navigateTo(LakiScreen.CustomerDashboard)
                                LakiScreen.DriverWhatsappSimulator -> viewModel.navigateTo(LakiScreen.DriverDashboard)
                                else -> viewModel.navigateTo(LakiScreen.Home)
                            }
                        }) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Kembali",
                                tint = LakiTextLight
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = LakiSurface,
                        titleContentColor = LakiTextLight
                    )
                )
            }
        },
        containerColor = LakiBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                LakiScreen.Home -> HomeScreen(viewModel, admins)
                LakiScreen.CustomerRegister -> CustomerRegisterScreen(viewModel)
                LakiScreen.CustomerLogin -> CustomerLoginScreen(viewModel)
                LakiScreen.CustomerDashboard -> CustomerDashboardScreen(viewModel, orders, customers)
                LakiScreen.CustomerOrderForm -> CustomerOrderFormScreen(viewModel)
                LakiScreen.CustomerActiveOrderTracking -> CustomerActiveOrderTrackingScreen(viewModel)
                LakiScreen.DriverRegister -> DriverRegisterScreen(viewModel)
                LakiScreen.DriverLogin -> DriverLoginScreen(viewModel)
                LakiScreen.DriverDashboard -> DriverDashboardScreen(viewModel)
                LakiScreen.DriverWhatsappSimulator -> DriverWhatsappSimulatorScreen(viewModel)
                LakiScreen.AdminRegister -> AdminRegisterScreen(viewModel)
                LakiScreen.AdminLogin -> AdminLoginScreen(viewModel)
                LakiScreen.AdminDashboard -> AdminDashboardScreen(viewModel, drivers, orders)
            }
        }
    }
}

// FORMAT RUPIAH HELPER
fun formatRupiah(amount: Double): String {
    val format = NumberFormat.getCurrencyInstance(Locale("in", "ID"))
    return format.format(amount).replace("Rp", "Rp ").replace(",00", "")
}

// FORMAT DATE HELPER
fun formatDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("id", "ID"))
    return sdf.format(Date(timestamp))
}

// GOOGLE MAPS INTENT TRIGGER
fun openLocationInGoogleMaps(context: android.content.Context, address: String) {
    try {
        val gmmIntentUri = Uri.parse("geo:0,0?q=" + Uri.encode(address))
        val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
        mapIntent.setPackage("com.google.android.apps.maps")
        context.startActivity(mapIntent)
    } catch (e: Exception) {
        Toast.makeText(context, "Google Maps tidak terpasang. Membuka di browser...", Toast.LENGTH_SHORT).show()
        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode(address)))
        context.startActivity(webIntent)
    }
}

// --- 1. HOME SCREEN ---
@Composable
fun HomeScreen(viewModel: LakiViewModel, admins: List<Admin>) {
    val context = LocalContext.current
    val isAdminDisabled = admins.size >= 2

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(LakiBackground, LakiSurface)
                )
            )
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Top
    ) {
        item {
            Spacer(modifier = Modifier.height(20.dp))

            // Beautiful Logo and Icon Simulation
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .background(
                        brush = Brush.radialGradient(
                            colors = listOf(LakiPrimary, Color.Transparent)
                        ),
                        shape = CircleShape
                    )
                    .clip(CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ElectricBike,
                    contentDescription = "Laki Logo Icon",
                    tint = Color.White,
                    modifier = Modifier.size(60.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Laki",
                fontSize = 42.sp,
                fontWeight = FontWeight.Black,
                color = LakiPrimary,
                textAlign = TextAlign.Center
            )
            Text(
                text = "(Langsung Kirim)",
                fontSize = 20.sp,
                fontWeight = FontWeight.SemiBold,
                color = LakiTextLight,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Dynamic Tagline Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = LakiSurface.copy(alpha = 0.85f)),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, LakiPrimary.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Laki ( langsung kirim) adalah jasa kirim barang instan yang langsung sampai hari ini tanpa harus mencari atau menunggu lama driver.",
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        fontWeight = FontWeight.Medium,
                        color = LakiTextLight,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Aplikasi jasa kirim yang dapat Anda percaya, sistem transparan, adil, dan manusiawi.",
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = LakiSecondary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "MASUK KE LAYANAN",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = LakiTextMuted,
                letterSpacing = 2.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        // Customer area selection card
        item {
            RoleCard(
                title = "Customer Portal",
                description = "Kirim barang instan sekarang, dapatkan driver dalam radius 5 KM.",
                icon = Icons.Default.Person,
                badgeText = "Sewa Jasa Driver",
                color = LakiSecondary,
                onClick = { viewModel.navigateTo(LakiScreen.CustomerLogin) }
            )
        }

        // Driver area selection card
        item {
            RoleCard(
                title = "Driver Portal",
                description = "Masuk atau daftar sebagai driver motor Laki & dapatkan penghasilan transparan.",
                icon = Icons.Default.SportsMotorsports,
                badgeText = "Bergabung Sebagai Driver",
                color = LakiPrimary,
                onClick = { viewModel.navigateTo(LakiScreen.DriverLogin) }
            )
        }

        // Admin area selection card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = LakiSurface),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = "Admin Area",
                                tint = if (isAdminDisabled) LakiTextMuted else Color.LightGray,
                                modifier = Modifier.size(32.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                text = "Admin Area",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isAdminDisabled) LakiTextMuted else LakiTextLight
                            )
                        }
                        Text(
                            text = "Kuota: ${admins.size}/2",
                            fontSize = 12.sp,
                            color = LakiSecondary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Kelola pendaftaran driver, audit orderan detail, pantau potongan komisi 8% dan kelola keuangan wallet.",
                        fontSize = 13.sp,
                        color = LakiTextMuted,
                        lineHeight = 18.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { viewModel.navigateTo(LakiScreen.AdminLogin) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
                        ) {
                            Text("Login Admin", color = Color.White)
                        }

                        // Registration Button (becoming disabled/greyed out if already has 2 admins!)
                        Button(
                            onClick = {
                                if (!isAdminDisabled) {
                                    viewModel.navigateTo(LakiScreen.AdminRegister)
                                }
                            },
                            enabled = !isAdminDisabled,
                            modifier = Modifier
                                .weight(1.2f)
                                .testTag("admin_register_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = LakiSecondary,
                                disabledContainerColor = Color.DarkGray.copy(alpha = 0.3f),
                                disabledContentColor = LakiTextMuted
                            )
                        ) {
                            Text(
                                text = if (isAdminDisabled) "Admin Terpenuhi" else "Daftar Admin Baru",
                                maxLines = 1
                            )
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}

@Composable
fun RoleCard(
    title: String,
    description: String,
    icon: ImageVector,
    badgeText: String,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = LakiSurface),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.2f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .background(color.copy(alpha = 0.15f), shape = CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = icon, contentDescription = null, tint = color)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(text = title, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = LakiTextLight)
                    Text(text = badgeText, fontSize = 12.sp, color = color, fontWeight = FontWeight.SemiBold)
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = description,
                fontSize = 13.sp,
                color = LakiTextMuted,
                lineHeight = 18.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "Masuk", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = color)
                Spacer(modifier = Modifier.width(4.dp))
                Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = color, modifier = Modifier.size(16.dp))
            }
        }
    }
}


// --- 2. CUSTOMER REGISTER ---
@Composable
fun CustomerRegisterScreen(viewModel: LakiViewModel) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var bankAccount by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Pendaftaran Akun Baru",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = LakiTextLight
            )
            Text(
                text = "Sistem kami mendeteksi duplikasi secara otomatis. Customer tidak boleh mendaftar menggunakan data driver yang sudah terdaftar.",
                fontSize = 13.sp,
                color = LakiTextMuted,
                lineHeight = 18.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
        }

        item {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nama Lengkap") },
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
            )
        }

        item {
            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Nomor Handphone Aktif") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) }
            )
        }

        item {
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Alamat Email / Username") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) }
            )
        }

        item {
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) }
            )
        }

        item {
            OutlinedTextField(
                value = bankAccount,
                onValueChange = { bankAccount = it },
                label = { Text("Nomor Rekening Bank (Opsional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
                leadingIcon = { Icon(Icons.Default.AccountBalance, contentDescription = null) }
            )
        }

        item {
            Button(
                onClick = {
                    viewModel.registerCustomer(
                        Customer(
                            name = name,
                            phone = phone,
                            email = email,
                            password = password,
                            bankAccount = bankAccount
                        )
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("customer_register_submit"),
                colors = ButtonDefaults.buttonColors(containerColor = LakiSecondary)
            ) {
                Text("Daftar Sekarang", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Text("Sudah punya akun?", color = LakiTextMuted)
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Login disini",
                    color = LakiSecondary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { viewModel.navigateTo(LakiScreen.CustomerLogin) }
                )
            }
        }
    }
}


// --- 3. CUSTOMER LOGIN ---
@Composable
fun CustomerLoginScreen(viewModel: LakiViewModel) {
    var phoneOrEmail by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.Person,
            contentDescription = null,
            tint = LakiSecondary,
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Login Customer Laki",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = LakiTextLight
        )
        Text(
            text = "Sewa jasa driver instan dalam sekejap",
            fontSize = 14.sp,
            color = LakiTextMuted,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        OutlinedTextField(
            value = phoneOrEmail,
            onValueChange = { phoneOrEmail = it },
            label = { Text("No Handphone atau Email") },
            modifier = Modifier.fillMaxWidth(),
            textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
        )
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) }
        )
        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { viewModel.loginCustomer(phoneOrEmail, password) },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("customer_login_submit"),
            colors = ButtonDefaults.buttonColors(containerColor = LakiSecondary)
        ) {
            Text("Masuk", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Text("Belum punya akun?", color = LakiTextMuted)
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "Daftar disini",
                color = LakiSecondary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { viewModel.navigateTo(LakiScreen.CustomerRegister) }
            )
        }
    }
}


// --- 4. CUSTOMER DASHBOARD ---
@Composable
fun CustomerDashboardScreen(viewModel: LakiViewModel, allOrders: List<Order>, allCustomers: List<Customer>) {
    val customer = viewModel.loggedInCustomer ?: return
    val customerOrders = allOrders.filter { it.customerId == customer.id }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Greetings card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = LakiSurface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Halo, ${customer.name}!",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = LakiTextLight
                    )
                    Text(
                        text = "Siap untuk mengirimkan barang dengan aman & transparan hari ini?",
                        fontSize = 13.sp,
                        color = LakiTextMuted,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    // Stats requested: "Jumlah customer yang sudah menggunakan aplikasi ini"
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(LakiBackground.copy(alpha = 0.5f), shape = RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Groups,
                            contentDescription = null,
                            tint = LakiSecondary,
                            modifier = Modifier.size(32.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Jumlah Pengguna Laki",
                                fontSize = 11.sp,
                                color = LakiTextMuted,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${allCustomers.size} Customer Terdaftar",
                                fontSize = 16.sp,
                                color = LakiTextLight,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }
            }
        }

        item {
            // Main Booking Button
            Button(
                onClick = { viewModel.navigateTo(LakiScreen.CustomerOrderForm) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("book_courier_button"),
                colors = ButtonDefaults.buttonColors(containerColor = LakiPrimary),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(imageVector = Icons.Default.ElectricBike, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Buat Order Kirim Barang",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = Color.White
                )
            }
        }

        item {
            Text(
                text = "Riwayat Pengiriman & Pengambilan Anda",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = LakiTextLight,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        if (customerOrders.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = LakiSurface.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Inbox,
                            contentDescription = null,
                            tint = LakiTextMuted,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Belum ada riwayat order.",
                            fontSize = 14.sp,
                            color = LakiTextMuted,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(customerOrders) { order ->
                OrderHistoryCard(order = order, onTrackClick = {
                    viewModel.selectOrderForTracking(order)
                    viewModel.navigateTo(LakiScreen.CustomerActiveOrderTracking)
                })
            }
        }
    }
}

@Composable
fun OrderHistoryCard(order: Order, onTrackClick: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = LakiSurface),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            width = 1.dp,
            color = when (order.status) {
                "COMPLETED" -> Color.Green.copy(alpha = 0.2f)
                "CANCELLED" -> Color.Red.copy(alpha = 0.2f)
                else -> LakiPrimary.copy(alpha = 0.3f)
            }
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Status & Time Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Order #${order.id}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = LakiTextLight
                )
                OrderStatusBadge(status = order.status)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Details
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Inventory,
                    contentDescription = null,
                    tint = LakiTextMuted,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${order.goodsType} (${order.goodsWeight} KG)",
                    fontSize = 13.sp,
                    color = LakiTextLight
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Pickup & Delivery Address History
            Row {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 4.dp)) {
                    Icon(Icons.Default.RadioButtonChecked, contentDescription = null, tint = LakiSecondary, modifier = Modifier.size(12.dp))
                    Box(modifier = Modifier.size(width = 2.dp, height = 24.dp).background(LakiTextMuted))
                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = LakiPrimary, modifier = Modifier.size(12.dp))
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(text = "Pengambilan:", fontSize = 10.sp, color = LakiTextMuted)
                    Text(text = order.pickupAddress, fontSize = 12.sp, color = LakiTextLight, maxLines = 1)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = "Pengantaran:", fontSize = 10.sp, color = LakiTextMuted)
                    Text(text = order.deliveryAddress, fontSize = 12.sp, color = LakiTextLight, maxLines = 1)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = Color.White.copy(alpha = 0.05f))
            Spacer(modifier = Modifier.height(12.dp))

            // Fare & Driver info requested: "Ada riwayat nama dan nomor HP driver yang sudah mengambil orderannya"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Tarif:", fontSize = 10.sp, color = LakiTextMuted)
                    Text(
                        text = formatRupiah(order.totalFare),
                        fontSize = 16.sp,
                        color = LakiPrimary,
                        fontWeight = FontWeight.Black
                    )
                }

                if (order.driverId != null) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(text = "Driver:", fontSize = 10.sp, color = LakiTextMuted)
                        Text(text = order.driverName ?: "", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = LakiTextLight)
                        Text(text = order.driverPhone ?: "", fontSize = 11.sp, color = LakiSecondary)
                    }
                } else if (order.status == "PENDING") {
                    Text(text = "Mencari Driver...", fontSize = 12.sp, color = LakiSecondary, fontWeight = FontWeight.SemiBold)
                }
            }

            // Tracking action button for active orders
            if (order.status != "COMPLETED" && order.status != "CANCELLED") {
                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = onTrackClick,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = LakiSecondary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Map, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Traking Pengiriman Live", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }
    }
}

@Composable
fun OrderStatusBadge(status: String) {
    val (text, color) = when (status) {
        "PENDING" -> "Menunggu Driver" to LakiPrimary
        "ACCEPTED" -> "Driver Menuju Lokasi" to LakiSecondary
        "AT_PICKUP" -> "Paket Diambil" to Color(0xFF3B82F6)
        "DELIVERED" -> "Sampai (Perlu Konfirmasi)" to Color(0xFFF59E0B)
        "COMPLETED" -> "Selesai" to Color.Green
        "CANCELLED" -> "Batal" to Color.Red
        else -> status to Color.Gray
    }

    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.15f), shape = RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text = text, color = color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}


// --- 5. CUSTOMER ORDER FORM ---
@Composable
fun CustomerOrderFormScreen(viewModel: LakiViewModel) {
    var pickupAddress by remember { mutableStateOf("") }
    var deliveryAddress by remember { mutableStateOf("") }
    var goodsType by remember { mutableStateOf("") }
    var goodsWeightStr by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf(viewModel.loggedInCustomer?.phone ?: "") }
    var recipientPhone by remember { mutableStateOf("") }
    var recipientName by remember { mutableStateOf("") }
    var distanceKmStr by remember { mutableStateOf("1.5") } // Default simulated distance
    var bankAccountRecipient by remember { mutableStateOf("") }

    val goodsWeight = goodsWeightStr.toDoubleOrNull() ?: 0.0
    val distanceKm = distanceKmStr.toDoubleOrNull() ?: 0.0

    // Fare calculation preview in UI
    val baseFare = distanceKm * 3000.0
    val surcharge = if (goodsWeight > 25.0) 5000.0 else 0.0
    val totalFare = baseFare + surcharge

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Pesan Jasa Kirim Laki",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = LakiTextLight
            )
            Text(
                text = "Silakan isi detail paket Anda dengan jujur & transparan.",
                fontSize = 13.sp,
                color = LakiTextMuted
            )
        }

        item {
            OutlinedTextField(
                value = pickupAddress,
                onValueChange = { pickupAddress = it },
                label = { Text("Alamat Pengambilan Lengkap") },
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
                leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = LakiSecondary) }
            )
        }

        item {
            OutlinedTextField(
                value = deliveryAddress,
                onValueChange = { deliveryAddress = it },
                label = { Text("Alamat Pengantaran Lengkap") },
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
                leadingIcon = { Icon(Icons.Default.Navigation, contentDescription = null, tint = LakiPrimary) }
            )
        }

        item {
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = goodsType,
                    onValueChange = { goodsType = it },
                    label = { Text("Jenis Barang") },
                    modifier = Modifier.weight(1.2f),
                    textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
                    placeholder = { Text("Dokumen, dll") }
                )

                OutlinedTextField(
                    value = goodsWeightStr,
                    onValueChange = { goodsWeightStr = it },
                    label = { Text("Berat (KG)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.weight(0.8f),
                    textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
                    placeholder = { Text("Max 25") }
                )
            }
        }

        // Weight warning / surcharge preview
        if (goodsWeight > 25.0) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF7F1D1D)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Berat melebihi batas 25KG! Tambahan biaya Rp 5.000 otomatis dikenakan.",
                            fontSize = 12.sp,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        item {
            OutlinedTextField(
                value = customerPhone,
                onValueChange = { customerPhone = it },
                label = { Text("No HP Anda (Customer Aktif)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) }
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = LakiSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(text = "Detail Penerima Paket", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LakiSecondary)

                    OutlinedTextField(
                        value = recipientName,
                        onValueChange = { recipientName = it },
                        label = { Text("Nama Penerima") },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = LocalTextStyle.current.copy(color = LakiTextLight)
                    )

                    OutlinedTextField(
                        value = recipientPhone,
                        onValueChange = { recipientPhone = it },
                        label = { Text("No HP Penerima Aktif") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = LocalTextStyle.current.copy(color = LakiTextLight)
                    )

                    OutlinedTextField(
                        value = bankAccountRecipient,
                        onValueChange = { bankAccountRecipient = it },
                        label = { Text("Nomor Rekening Penerima (Opsional)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = LocalTextStyle.current.copy(color = LakiTextLight)
                    )
                }
            }
        }

        item {
            // Distance selector simulation
            Card(
                colors = CardDefaults.cardColors(containerColor = LakiSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Simulasi Jarak Jangkauan", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LakiPrimary)
                    Text(
                        text = "Radius maksimal layanan adalah 5 KM dari driver terdekat.",
                        fontSize = 11.sp,
                        color = LakiTextMuted,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Pilih Jarak Pengiriman:", fontSize = 13.sp, color = LakiTextLight)
                        Text(text = "$distanceKm KM", fontSize = 18.sp, color = LakiPrimary, fontWeight = FontWeight.Black)
                    }

                    Slider(
                        value = distanceKm.toFloat(),
                        onValueChange = { distanceKmStr = String.format(Locale.US, "%.1f", it) },
                        valueRange = 0.5f..8.0f,
                        steps = 15,
                        colors = SliderDefaults.colors(
                            activeTrackColor = LakiPrimary,
                            thumbColor = LakiPrimary
                        )
                    )

                    if (distanceKm > 5.0) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                            Icon(Icons.Default.Error, contentDescription = null, tint = Color.Red, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Jarak melebihi 5 KM! Anda tidak akan mendapatkan driver.",
                                fontSize = 12.sp,
                                color = Color.Red,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        item {
            // Pricing Preview
            Card(
                colors = CardDefaults.cardColors(containerColor = LakiSurface.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, LakiSecondary.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "Rincian Transparansi Tarif", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = LakiSecondary)

                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(text = "Biaya Jarak ($distanceKm KM x Rp 3.000)", fontSize = 13.sp, color = LakiTextLight)
                        Text(text = formatRupiah(baseFare), fontSize = 13.sp, color = LakiTextLight)
                    }

                    if (surcharge > 0) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(text = "Surcharge Berat (> 25KG)", fontSize = 13.sp, color = Color.Red)
                            Text(text = formatRupiah(surcharge), fontSize = 13.sp, color = Color.Red)
                        }
                    }

                    Divider(color = Color.White.copy(alpha = 0.1f), modifier = Modifier.padding(vertical = 4.dp))

                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(text = "Total Tarif Dibayar", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = LakiTextLight)
                        Text(text = formatRupiah(totalFare), fontSize = 18.sp, fontWeight = FontWeight.Black, color = LakiPrimary)
                    }

                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(text = "Potongan Komisi Laki (8%)", fontSize = 11.sp, color = LakiTextMuted)
                        Text(text = "- " + formatRupiah(totalFare * 0.08), fontSize = 11.sp, color = LakiTextMuted)
                    }

                    Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(text = "Pendapatan Bersih Driver", fontSize = 12.sp, color = LakiSecondary, fontWeight = FontWeight.Bold)
                        Text(text = formatRupiah(totalFare * 0.92), fontSize = 12.sp, color = LakiSecondary, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        item {
            Button(
                onClick = {
                    viewModel.submitOrder(
                        pickupAddress = pickupAddress,
                        deliveryAddress = deliveryAddress,
                        goodsType = goodsType,
                        goodsWeight = goodsWeight,
                        customerPhone = customerPhone,
                        recipientPhone = recipientPhone,
                        recipientName = recipientName,
                        distanceKm = distanceKm,
                        bankAccountCustomer = viewModel.loggedInCustomer?.bankAccount ?: "",
                        bankAccountRecipient = bankAccountRecipient
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("submit_order_button"),
                colors = ButtonDefaults.buttonColors(containerColor = LakiPrimary)
            ) {
                Text("Kirim Sekarang (Instan Laki)", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}


// --- 6. CUSTOMER ACTIVE ORDER TRACKING (GOOGLE MAPS LIVE MAP SIMULATION) ---
@Composable
fun CustomerActiveOrderTrackingScreen(viewModel: LakiViewModel) {
    val context = LocalContext.current
    val order = viewModel.selectedOrderForTracking

    if (order == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(text = "Tidak ada orderan aktif yang dipilih.", color = LakiTextMuted)
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Traking Pengantaran Barang",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = LakiTextLight
            )
            Text(
                text = "Pantau kurir motor Anda secara real-time",
                fontSize = 12.sp,
                color = LakiTextMuted
            )
        }

        // Live Simulated Map Widget!
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, LakiSecondary.copy(alpha = 0.4f))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(LakiSurface)
                ) {
                    // Modern Styled Simulated Map Grid
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "GOOGLE MAPS LIVE SIMULASI",
                                color = LakiSecondary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Box(
                                modifier = Modifier
                                    .background(Color.Red, shape = CircleShape)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(6.dp)
                                            .background(Color.White, shape = CircleShape)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(text = "LIVE", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }

                        // Display simulated tracking route
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "Rute: ${order.pickupAddress} -> ${order.deliveryAddress}",
                                color = LakiTextLight,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                textAlign = TextAlign.Center
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocationOn, contentDescription = null, tint = LakiSecondary, modifier = Modifier.size(20.dp))
                                Text(text = " • • • • • • ", color = LakiPrimary, fontWeight = FontWeight.Bold)
                                Icon(Icons.Default.ElectricBike, contentDescription = null, tint = LakiPrimary, modifier = Modifier.size(30.dp))
                                Text(text = " • • • • • • ", color = LakiSecondary, fontWeight = FontWeight.Bold)
                                Icon(Icons.Default.Flag, contentDescription = null, tint = Color.Green, modifier = Modifier.size(20.dp))
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Jarak Pengiriman: ${order.distanceKm} KM",
                                color = LakiTextMuted,
                                fontSize = 11.sp
                            )
                        }

                        // Real Google Maps Trigger button as requested!
                        Button(
                            onClick = {
                                val destination = if (order.status == "ACCEPTED") order.pickupAddress else order.deliveryAddress
                                openLocationInGoogleMaps(context, destination)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(36.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = LakiSecondary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(imageVector = Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "Buka di Google Maps Asli", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Active Order Step Status Progress
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = LakiSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(text = "Status Pengiriman", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LakiPrimary)

                    ProgressStep(
                        title = "Menunggu Driver",
                        desc = "Orderan Anda sedang disiarkan ke WhatsApp Driver terdekat.",
                        isCompleted = order.status != "PENDING" && order.status != "CANCELLED",
                        isActive = order.status == "PENDING"
                    )

                    ProgressStep(
                        title = "Driver Menuju Lokasi Pengambilan",
                        desc = if (order.driverName != null) "Kurir ${order.driverName} (${order.driverPhone}) sedang menuju lokasi penjemputan paket." else "Menunggu penerimaan.",
                        isCompleted = order.status != "PENDING" && order.status != "ACCEPTED" && order.status != "CANCELLED",
                        isActive = order.status == "ACCEPTED"
                    )

                    ProgressStep(
                        title = "Paket Diambil",
                        desc = "Driver sudah tiba di lokasi pengambilan & mengambil foto paket.",
                        isCompleted = order.status == "DELIVERED" || order.status == "COMPLETED",
                        isActive = order.status == "AT_PICKUP"
                    )

                    ProgressStep(
                        title = "Sampai di Tujuan / Selesai",
                        desc = "Paket sudah berhasil dikirimkan ke alamat tujuan.",
                        isCompleted = order.status == "COMPLETED",
                        isActive = order.status == "DELIVERED"
                    )
                }
            }
        }

        // Driver details with Selfie Photo
        if (order.driverId != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = LakiSurface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = "Detail Driver Anda", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LakiSecondary)
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            // Driver Selfie Display requested: "kemudian foto selfie driver akan tampil di profil driver"
                            // Since we simulate physical photos, we show a gorgeous profile icon representing the selfie!
                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .background(LakiPrimary.copy(alpha = 0.2f), shape = CircleShape)
                                    .clip(CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.SportsMotorsports,
                                    contentDescription = "Driver Selfie",
                                    tint = LakiPrimary,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(16.dp))
                            Column {
                                Text(text = order.driverName ?: "", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = LakiTextLight)
                                Text(text = "No HP: ${order.driverPhone ?: ""}", fontSize = 13.sp, color = LakiTextMuted)
                                Text(text = "No Rekening: ${order.bankAccountDriver}", fontSize = 11.sp, color = LakiSecondary)
                            }
                        }
                    }
                }
            }
        }

        // Display photos taken by driver dynamically for Customer
        if (order.pickupPhoto != null || order.deliveryPhoto != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = LakiSurface),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(text = "Foto Bukti Pengiriman (WhatsApp Auto-Send)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LakiPrimary)

                        if (order.pickupPhoto != null) {
                            Column {
                                Text(text = "Foto Pengambilan (Terkirim Ke Customer):", fontSize = 11.sp, color = LakiTextMuted)
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(100.dp)
                                        .background(Color.DarkGray, shape = RoundedCornerShape(6.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.PhotoCamera, contentDescription = null, tint = LakiSecondary)
                                        Text(text = "Foto Paket Berhasil Diambil", color = Color.White, fontSize = 11.sp)
                                    }
                                }
                            }
                        }

                        if (order.deliveryPhoto != null) {
                            Column {
                                Text(text = "Foto Pengantaran (Terkirim Ke Penerima ${order.recipientName}):", fontSize = 11.sp, color = LakiTextMuted)
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(100.dp)
                                        .background(Color.DarkGray, shape = RoundedCornerShape(6.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.TaskAlt, contentDescription = null, tint = Color.Green)
                                        Text(text = "Diterima oleh: ${order.recipientName}", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Button(
                onClick = { viewModel.navigateTo(LakiScreen.CustomerDashboard) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray)
            ) {
                Text("Kembali ke Dasbor")
            }
        }
    }
}

@Composable
fun ProgressStep(title: String, desc: String, isCompleted: Boolean, isActive: Boolean) {
    Row {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(20.dp)
                    .background(
                        color = when {
                            isCompleted -> Color.Green
                            isActive -> LakiPrimary
                            else -> Color.DarkGray
                        },
                        shape = CircleShape
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isCompleted) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(12.dp))
                }
            }
            Box(
                modifier = Modifier
                    .size(width = 2.dp, height = 32.dp)
                    .background(if (isCompleted) Color.Green else Color.DarkGray)
            )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (isActive || isCompleted) LakiTextLight else LakiTextMuted
            )
            Text(
                text = desc,
                fontSize = 11.sp,
                color = LakiTextMuted,
                lineHeight = 14.sp
            )
        }
    }
}


// --- 7. DRIVER REGISTER ---
@Composable
fun DriverRegisterScreen(viewModel: LakiViewModel) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var bankAccount by remember { mutableStateOf("") }

    // Mock Photo variables
    var hasKtp by remember { mutableStateOf(false) }
    var hasSim by remember { mutableStateOf(false) }
    var hasSelfie by remember { mutableStateOf(false) }
    var hasVehiclePhoto by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "Pendaftaran Driver Laki",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = LakiTextLight
            )
            Text(
                text = "Akun Anda harus disetujui Admin sebelum dapat login & mengambil orderan.",
                fontSize = 13.sp,
                color = LakiTextMuted,
                modifier = Modifier.padding(top = 4.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
        }

        item {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Nama Lengkap Sesuai KTP") },
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
                leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
            )
        }

        item {
            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Nomor Handphone Aktif") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
                leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) }
            )
        }

        item {
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email / Username") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
                leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) }
            )
        }

        item {
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Password") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
                leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) }
            )
        }

        item {
            OutlinedTextField(
                value = bankAccount,
                onValueChange = { bankAccount = it },
                label = { Text("Nomor Rekening Bank (BCA/Mandiri dll)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
                leadingIcon = { Icon(Icons.Default.AccountBalance, contentDescription = null) }
            )
        }

        // Mock Photo uploads as requested: "foto KTP, foto SIM, foto selfie, foto surat kendaraan, kemudian foto selfie driver akan tampil di profil driver"
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = LakiSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(text = "Dokumen Pendukung (Wajib)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LakiPrimary)

                    PhotoUploadSim(label = "Unggah Foto KTP", hasPhoto = hasKtp, onToggle = { hasKtp = !hasKtp })
                    PhotoUploadSim(label = "Unggah Foto SIM C", hasPhoto = hasSim, onToggle = { hasSim = !hasSim })
                    PhotoUploadSim(label = "Unggah Foto Selfie Driver (Tampil di Profil)", hasPhoto = hasSelfie, onToggle = { hasSelfie = !hasSelfie })
                    PhotoUploadSim(label = "Unggah Foto STNK / Surat Kendaraan", hasPhoto = hasVehiclePhoto, onToggle = { hasVehiclePhoto = !hasVehiclePhoto })
                }
            }
        }

        item {
            Button(
                onClick = {
                    viewModel.registerDriver(
                        Driver(
                            name = name,
                            phone = phone,
                            email = email,
                            password = password,
                            bankAccount = bankAccount,
                            ktpPhoto = if (hasKtp) "MOCK_KTP_OK" else "",
                            simPhoto = if (hasSim) "MOCK_SIM_OK" else "",
                            selfiePhoto = if (hasSelfie) "MOCK_SELFIE_OK" else "",
                            vehiclePhoto = if (hasVehiclePhoto) "MOCK_STNK_OK" else ""
                        )
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("driver_register_submit"),
                colors = ButtonDefaults.buttonColors(containerColor = LakiPrimary)
            ) {
                Text("Kirim Pengajuan Jadi Driver", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                Text("Sudah mendaftar?", color = LakiTextMuted)
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Login disini",
                    color = LakiPrimary,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { viewModel.navigateTo(LakiScreen.DriverLogin) }
                )
            }
            Spacer(modifier = Modifier.height(30.dp))
        }
    }
}

@Composable
fun PhotoUploadSim(label: String, hasPhoto: Boolean, onToggle: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(LakiBackground, shape = RoundedCornerShape(8.dp))
            .clickable(onClick = onToggle)
            .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (hasPhoto) Icons.Default.CheckCircle else Icons.Default.AddPhotoAlternate,
                contentDescription = null,
                tint = if (hasPhoto) Color.Green else LakiTextMuted
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(text = label, color = LakiTextLight, fontSize = 13.sp)
        }
        Text(
            text = if (hasPhoto) "Terlampir" else "Unggah",
            color = if (hasPhoto) Color.Green else LakiPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}


// --- 8. DRIVER LOGIN ---
@Composable
fun DriverLoginScreen(viewModel: LakiViewModel) {
    var phoneOrEmail by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.SportsMotorsports,
            contentDescription = null,
            tint = LakiPrimary,
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Login Driver Laki",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = LakiTextLight
        )
        Text(
            text = "Mulai terima orderan instan hari ini",
            fontSize = 14.sp,
            color = LakiTextMuted,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        OutlinedTextField(
            value = phoneOrEmail,
            onValueChange = { phoneOrEmail = it },
            label = { Text("No Handphone atau Email") },
            modifier = Modifier.fillMaxWidth(),
            textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) }
        )
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) }
        )
        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { viewModel.loginDriver(phoneOrEmail, password) },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("driver_login_submit"),
            colors = ButtonDefaults.buttonColors(containerColor = LakiPrimary)
        ) {
            Text("Masuk", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color.White)
        }

        Spacer(modifier = Modifier.height(16.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            Text("Ingin bergabung jadi Driver?", color = LakiTextMuted)
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "Daftar disini",
                color = LakiPrimary,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { viewModel.navigateTo(LakiScreen.DriverRegister) }
            )
        }
    }
}


// --- 9. DRIVER DASHBOARD ---
@Composable
fun DriverDashboardScreen(viewModel: LakiViewModel) {
    val driver = viewModel.loggedInDriver ?: return
    val stats = viewModel.getDriverEarningsStats(driver.id)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            // Profile & Selfie header requested
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = LakiSurface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(modifier = Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .background(LakiPrimary.copy(alpha = 0.2f), shape = CircleShape)
                            .clip(CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        // Selfie image display simulation
                        Icon(
                            imageVector = Icons.Default.SportsMotorsports,
                            contentDescription = "Driver Selfie",
                            tint = LakiPrimary,
                            modifier = Modifier.size(44.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = driver.name,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = LakiTextLight
                        )
                        Text(text = "Driver Laki Aktif • Terverifikasi", fontSize = 12.sp, color = LakiSecondary, fontWeight = FontWeight.Bold)
                        Text(text = "HP: ${driver.phone}", fontSize = 12.sp, color = LakiTextMuted)
                    }
                }
            }
        }

        // WhatsApp Simulator Link (High prominence)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = WhatsAppGreen.copy(alpha = 0.15f)),
                border = BorderStroke(1.dp, WhatsAppGreen.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo(LakiScreen.DriverWhatsappSimulator) }
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(WhatsAppGreen, shape = CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Chat, contentDescription = null, tint = Color.White)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(text = "Buka Simulator WhatsApp Laki", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                            Text(text = "Pantau orderan masuk, ambil order, & kirim foto", fontSize = 11.sp, color = LakiTextMuted)
                        }
                    }
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = WhatsAppGreen)
                }
            }
        }

        // Earnings stats requested: "Total pendapatan harian, mingguan, bulanan"
        item {
            Text(
                text = "Statistik Pendapatan Bersih Driver",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = LakiTextLight
            )
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                EarningsStatsBox(title = "Harian", amount = stats.daily, color = LakiPrimary, modifier = Modifier.weight(1f))
                EarningsStatsBox(title = "Mingguan", amount = stats.weekly, color = LakiSecondary, modifier = Modifier.weight(1f))
                EarningsStatsBox(title = "Bulanan", amount = stats.monthly, color = Color.Green, modifier = Modifier.weight(1f))
            }
        }

        // Riwayat Orderan yang sudah diselesaikan (Completed order history)
        item {
            Text(
                text = "Riwayat Orderan Selesai (${stats.completedOrders.size})",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = LakiTextLight,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        if (stats.completedOrders.isEmpty()) {
            item {
                Text(text = "Belum ada orderan selesai.", fontSize = 13.sp, color = LakiTextMuted)
            }
        } else {
            items(stats.completedOrders) { order ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = LakiSurface),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(text = "Order #${order.id}", fontWeight = FontWeight.Bold, color = LakiTextLight)
                            Text(text = formatDate(order.completedAt ?: 0), fontSize = 11.sp, color = LakiTextMuted)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "Rute: ${order.pickupAddress} -> ${order.deliveryAddress}", fontSize = 12.sp, color = LakiTextLight)

                        // Sender/Recipient details requested: "Riwayat pengambilan paket dan pengiriman paket beserta nama pengirim, nama penerima, nomor handphone pengirim dan nomor penerima paket"
                        Spacer(modifier = Modifier.height(8.dp))
                        Divider(color = Color.White.copy(alpha = 0.05f))
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(text = "Pengirim:", fontSize = 9.sp, color = LakiTextMuted)
                                Text(text = order.customerName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LakiTextLight)
                                Text(text = order.customerPhone, fontSize = 10.sp, color = LakiTextMuted)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "Penerima:", fontSize = 9.sp, color = LakiTextMuted)
                                Text(text = order.recipientName, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = LakiTextLight)
                                Text(text = order.recipientPhone, fontSize = 10.sp, color = LakiTextMuted)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(text = "Hasil Bersih (Komisi Terpotong 8%):", fontSize = 11.sp, color = LakiSecondary)
                            Text(text = formatRupiah(order.driverEarnings), fontSize = 13.sp, fontWeight = FontWeight.Black, color = LakiSecondary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EarningsStatsBox(title: String, amount: Double, color: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = LakiSurface)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = title, fontSize = 11.sp, color = LakiTextMuted, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = formatRupiah(amount),
                fontSize = 13.sp,
                fontWeight = FontWeight.Black,
                color = color,
                textAlign = TextAlign.Center
            )
        }
    }
}


// --- 10. WHATSAPP SIMULATOR FOR DRIVER ---
@Composable
fun DriverWhatsappSimulatorScreen(viewModel: LakiViewModel) {
    val context = LocalContext.current
    val orders by viewModel.allOrders.collectAsStateWithLifecycle()
    val driver = viewModel.loggedInDriver ?: return

    // Show latest active matched order or allow driver to select active matched order
    val activeOrders = orders.filter {
        (it.driverId == null && it.status == "PENDING") ||
                (it.driverId == driver.id && it.status != "COMPLETED" && it.status != "CANCELLED")
    }

    if (activeOrders.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(WhatsAppChatBgDark)
                .padding(24.dp),
            contentAlignment = Alignment.Center
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = LakiSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = WhatsAppGreen, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "WhatsApp Chat Kosong",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Text(
                        text = "Belum ada orderan masuk ke nomor WhatsApp Anda saat ini. Pastikan ada orderan baru yang dipesan oleh Customer dalam radius 5 KM.",
                        fontSize = 12.sp,
                        color = LakiTextMuted,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
        return
    }

    // Display the WhatsApp message stream simulator
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(WhatsAppChatBgDark)
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.Yellow.copy(alpha = 0.1f), shape = RoundedCornerShape(8.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = "🔐 Enkripsi End-to-End. Ini adalah simulasi penerimaan pesanan otomatis langsung di aplikasi WhatsApp Driver.",
                    fontSize = 10.sp,
                    color = Color.LightGray,
                    textAlign = TextAlign.Center
                )
            }
        }

        items(activeOrders) { order ->
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = if (order.driverId == driver.id) Alignment.End else Alignment.Start
            ) {
                // Sender Info Label
                Text(
                    text = if (order.driverId == driver.id) "Sistem Laki (Ke Anda)" else "Sistem Laki (Pemberitahuan Order Baru)",
                    fontSize = 10.sp,
                    color = WhatsAppGreen,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                )

                // WhatsApp Green styled card
                Card(
                    modifier = Modifier.widthIn(max = 310.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1F2C34)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "🚚 ORDERAN MASUK - LAKI INSTAN",
                            fontWeight = FontWeight.Black,
                            fontSize = 13.sp,
                            color = WhatsAppGreen
                        )
                        Spacer(modifier = Modifier.height(10.dp))

                        // Detail Pengambilan
                        Text(text = "📍 DETAIL PENGAMBILAN PAKET:", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = LakiSecondary)
                        Text(text = order.pickupAddress, fontSize = 12.sp, color = Color.White)

                        // Google Maps Integration for Pickup
                        Spacer(modifier = Modifier.height(4.dp))
                        Button(
                            onClick = { openLocationInGoogleMaps(context, order.pickupAddress) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                            modifier = Modifier.height(30.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)
                        ) {
                            Icon(Icons.Default.Map, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Buka Maps Lokasi Jemput", fontSize = 10.sp, color = Color.White)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Detail Pengantaran
                        Text(text = "🏁 DETAIL PENGANTARAN PAKET:", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = LakiPrimary)
                        Text(text = order.deliveryAddress, fontSize = 12.sp, color = Color.White)

                        // Google Maps Integration for Delivery
                        Spacer(modifier = Modifier.height(4.dp))
                        Button(
                            onClick = { openLocationInGoogleMaps(context, order.deliveryAddress) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                            modifier = Modifier.height(30.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp)
                        ) {
                            Icon(Icons.Default.Map, contentDescription = null, modifier = Modifier.size(12.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "Buka Maps Lokasi Antar", fontSize = 10.sp, color = Color.White)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Package info
                        Text(text = "📦 DETAIL PAKET:", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.White)
                        Text(text = "Jenis: ${order.goodsType}\nBerat: ${order.goodsWeight} KG", fontSize = 12.sp, color = Color.LightGray)

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = Color.White.copy(alpha = 0.1f))
                        Spacer(modifier = Modifier.height(12.dp))

                        // Core Driver Actions in Whatsapp: Ambil Order, Cancel & Photo captures
                        if (order.status == "PENDING") {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Cancel Button requested: "Tambahkan juga menu cancel di whatsapp driver"
                                Button(
                                    onClick = { viewModel.driverCancelOrder(order.id) },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text("Cancel", fontSize = 12.sp, color = Color.White)
                                }

                                // Accept Button requested: "ada menu ambil order, setelah menu ambil order di klik baru detail pengambilan paket muncul berserta tarif yang akan di peroleh oleh driver"
                                Button(
                                    onClick = { viewModel.driverAcceptOrder(order.id) },
                                    modifier = Modifier.weight(1.2f),
                                    colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text("Ambil Order", fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        } else {
                            // ACCEPTED, AT_PICKUP, or DELIVERED status - show driver instructions & photo uploads
                            Text(
                                text = "💰 TARIF BERSIH ANDA:",
                                fontSize = 11.sp,
                                color = WhatsAppGreen,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = formatRupiah(order.driverEarnings),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = WhatsAppGreen
                            )
                            Text(
                                text = "Komisi Laki 8% (${formatRupiah(order.adminCommission)}) terpotong otomatis.",
                                fontSize = 10.sp,
                                color = LakiTextMuted
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            when (order.status) {
                                "ACCEPTED" -> {
                                    Text(
                                        text = "📍 Ambil Paket dari Customer:\nSilakan menuju lokasi pengambilan. Klik tombol di bawah untuk konfirmasi terima paket & WAJIB foto paket.",
                                        fontSize = 11.sp,
                                        color = Color.Yellow
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))

                                    Button(
                                        onClick = {
                                            // Mocking photo capture base64
                                            viewModel.driverConfirmPickup(order.id, "MOCK_PHOTO_PICKUP")
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = LakiSecondary)
                                    ) {
                                        Icon(Icons.Default.PhotoCamera, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Ambil Foto Paket & Konfirmasi", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                    }
                                }

                                "AT_PICKUP" -> {
                                    var recipientNameInput by remember { mutableStateOf("") }

                                    Text(
                                        text = "🏁 Antar Paket ke Penerima:\nSilakan menuju lokasi pengantaran. Setelah sampai, ambil foto paket dan tulis nama penerima.",
                                        fontSize = 11.sp,
                                        color = Color.Yellow
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))

                                    OutlinedTextField(
                                        value = recipientNameInput,
                                        onValueChange = { recipientNameInput = it },
                                        label = { Text("Nama Penerima Paket") },
                                        modifier = Modifier.fillMaxWidth(),
                                        textStyle = LocalTextStyle.current.copy(color = Color.White),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = WhatsAppGreen,
                                            unfocusedBorderColor = Color.LightGray
                                        )
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))

                                    Button(
                                        onClick = {
                                            viewModel.driverConfirmDelivery(order.id, "MOCK_PHOTO_DELIVERY", recipientNameInput)
                                        },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = LakiPrimary)
                                    ) {
                                        Icon(Icons.Default.PhotoCamera, contentDescription = null)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Kirim Foto & Antar Selesai", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                "DELIVERED" -> {
                                    Text(
                                        text = "💵 Pembayaran & Selesai:\nMenunggu pembayaran dari customer sebesar ${formatRupiah(order.totalFare)} (Cash atau Transfer).\nKlik Selesaikan jika uang sudah diterima.",
                                        fontSize = 11.sp,
                                        color = Color.Green
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))

                                    Button(
                                        onClick = { viewModel.driverCompleteOrder(order.id) },
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = ButtonDefaults.buttonColors(containerColor = WhatsAppGreen)
                                    ) {
                                        Text("Selesaikan Transaksi", fontWeight = FontWeight.Bold, color = Color.Black)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


// --- 11. ADMIN REGISTER ---
@Composable
fun AdminRegisterScreen(viewModel: LakiViewModel) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var bankAccount by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.AdminPanelSettings,
            contentDescription = null,
            tint = LakiSecondary,
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Daftar Admin Laki",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = LakiTextLight
        )
        Text(
            text = "Kuota pendaftaran otomatis dibatasi maksimal 2 admin.",
            fontSize = 13.sp,
            color = LakiTextMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Nama Lengkap Admin") },
            modifier = Modifier.fillMaxWidth(),
            textStyle = LocalTextStyle.current.copy(color = LakiTextLight)
        )
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Alamat Email") },
            modifier = Modifier.fillMaxWidth(),
            textStyle = LocalTextStyle.current.copy(color = LakiTextLight)
        )
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            textStyle = LocalTextStyle.current.copy(color = LakiTextLight)
        )
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = bankAccount,
            onValueChange = { bankAccount = it },
            label = { Text("Nomor Rekening Penerima Penarikan Wallet") },
            modifier = Modifier.fillMaxWidth(),
            textStyle = LocalTextStyle.current.copy(color = LakiTextLight)
        )
        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                viewModel.registerAdmin(
                    Admin(
                        name = name,
                        email = email,
                        password = password,
                        bankAccount = bankAccount
                    )
                )
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("admin_register_submit"),
            colors = ButtonDefaults.buttonColors(containerColor = LakiSecondary)
        ) {
            Text("Daftar Sebagai Admin", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}


// --- 12. ADMIN LOGIN ---
@Composable
fun AdminLoginScreen(viewModel: LakiViewModel) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.AdminPanelSettings,
            contentDescription = null,
            tint = LakiSecondary,
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "Login Admin Laki",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = LakiTextLight
        )
        Text(
            text = "Kelola data pendaftaran & audit keuangan",
            fontSize = 14.sp,
            color = LakiTextMuted,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email Admin") },
            modifier = Modifier.fillMaxWidth(),
            textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) }
        )
        Spacer(modifier = Modifier.height(16.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            textStyle = LocalTextStyle.current.copy(color = LakiTextLight),
            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) }
        )
        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = { viewModel.loginAdmin(email, password) },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("admin_login_submit"),
            colors = ButtonDefaults.buttonColors(containerColor = LakiSecondary)
        ) {
            Text("Masuk", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}


// --- 13. ADMIN DASHBOARD ---
@Composable
fun AdminDashboardScreen(viewModel: LakiViewModel, driversList: List<Driver>, ordersList: List<Order>) {
    val admin = viewModel.loggedInAdmin ?: return
    var selectedTab by remember { mutableIntStateOf(0) }

    val pendingDrivers = driversList.filter { it.status == "PENDING" }
    val approvedDrivers = driversList.filter { it.status == "APPROVED" }

    Column(modifier = Modifier.fillMaxSize()) {
        // Tab Headers
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = LakiSurface,
            contentColor = LakiPrimary
        ) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }) {
                Box(modifier = Modifier.padding(12.dp)) {
                    Text(text = "Persetujuan Driver (${pendingDrivers.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }) {
                Box(modifier = Modifier.padding(12.dp)) {
                    Text(text = "Audit Transaksi (${ordersList.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }) {
                Box(modifier = Modifier.padding(12.dp)) {
                    Text(text = "Wallet Admin & Support", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Tab Content
        Box(
            modifier = Modifier
                .fillMaxSize()
                .weight(1f)
                .padding(16.dp)
        ) {
            when (selectedTab) {
                0 -> AdminDriverApprovalsTab(viewModel, pendingDrivers, approvedDrivers)
                1 -> AdminTransactionsTab(ordersList)
                2 -> AdminWalletAndSupportTab(viewModel, admin, ordersList)
            }
        }
    }
}

@Composable
fun AdminDriverApprovalsTab(viewModel: LakiViewModel, pending: List<Driver>, approved: List<Driver>) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text(text = "Menunggu Persetujuan (${pending.size})", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = LakiTextLight)
        }

        if (pending.isEmpty()) {
            item {
                Text(text = "Tidak ada pengajuan driver baru.", fontSize = 13.sp, color = LakiTextMuted)
            }
        } else {
            items(pending) { driver ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = LakiSurface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(text = "Nama: ${driver.name}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = LakiTextLight)
                        Text(text = "No HP: ${driver.phone}\nEmail: ${driver.email}\nRekening: ${driver.bankAccount}", fontSize = 12.sp, color = LakiTextMuted)

                        // Attachments checklist view
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            DocumentBadge(label = "KTP")
                            DocumentBadge(label = "SIM")
                            DocumentBadge(label = "Selfie")
                            DocumentBadge(label = "STNK")
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = { viewModel.setDriverStatus(driver.id, "REJECTED") },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Tolak")
                            }

                            Button(
                                onClick = { viewModel.setDriverStatus(driver.id, "APPROVED") },
                                colors = ButtonDefaults.buttonColors(containerColor = LakiSecondary),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("Setujui", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
            Text(text = "Driver Aktif Disetujui (${approved.size})", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = LakiTextLight)
        }

        if (approved.isEmpty()) {
            item {
                Text(text = "Belum ada driver yang disetujui.", fontSize = 13.sp, color = LakiTextMuted)
            }
        } else {
            items(approved) { driver ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = LakiSurface.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = driver.name, fontWeight = FontWeight.Bold, color = LakiTextLight)
                            Text(text = driver.phone, fontSize = 12.sp, color = LakiTextMuted)
                        }
                        Box(
                            modifier = Modifier
                                .background(Color.Green.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = "AKTIF", color = Color.Green, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DocumentBadge(label: String) {
    Box(
        modifier = Modifier
            .background(LakiPrimary.copy(alpha = 0.1f), shape = RoundedCornerShape(4.dp))
            .border(0.5.dp, LakiPrimary.copy(alpha = 0.3f), shape = RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(text = label, color = LakiPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun AdminTransactionsTab(orders: List<Order>) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text(text = "Semua Riwayat Transaksi Audit Laki", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = LakiTextLight)
        }

        if (orders.isEmpty()) {
            item {
                Text(text = "Belum ada transaksi di database.", fontSize = 13.sp, color = LakiTextMuted)
            }
        } else {
            items(orders) { order ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = LakiSurface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                            Text(text = "Transaksi #${order.id}", fontWeight = FontWeight.Bold, color = LakiTextLight)
                            OrderStatusBadge(status = order.status)
                        }

                        Divider(color = Color.White.copy(alpha = 0.05f))

                        Text(text = "📍 Penjemputan: ${order.pickupAddress}", fontSize = 12.sp, color = LakiTextLight)
                        Text(text = "🏁 Pengantaran: ${order.deliveryAddress}", fontSize = 12.sp, color = LakiTextLight)

                        Text(text = "📦 Detail: ${order.goodsType} | ${order.goodsWeight} KG", fontSize = 12.sp, color = LakiTextMuted)

                        // Full accounts requested in view:
                        // "alamat pengambilan, pengantar paket, tarif yang di bayarkan, berat barang, jenis barang, nama pengirim/penerima paket, nomor rekening driver, nomor rekening customer, nomor rekening penerima paket, nomor handphone driver, nomor handphone customer, nomor handphone penerima, nama customer, nama driver, nama penerima paket"
                        Card(
                            colors = CardDefaults.cardColors(containerColor = LakiBackground.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(text = "📋 DETAIL PIHAK TERKAIT & AUDIT AKUN:", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = LakiSecondary)

                                Text(text = "👤 CUSTOMER/PENGIRIM:\n• Nama: ${order.customerName}\n• HP: ${order.customerPhone}\n• Rekening: ${order.bankAccountCustomer}", fontSize = 11.sp, color = LakiTextLight)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = "👤 DRIVER/KURIR:\n• Nama: ${order.driverName ?: ' '}\n• HP: ${order.driverPhone ?: ' '}\n• Rekening: ${order.bankAccountDriver}", fontSize = 11.sp, color = LakiTextLight)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = "👤 PENERIMA PAKET:\n• Nama: ${order.recipientName}\n• HP: ${order.recipientPhone}\n• Rekening: ${order.bankAccountRecipient}", fontSize = 11.sp, color = LakiTextLight)
                            }
                        }

                        Divider(color = Color.White.copy(alpha = 0.05f))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(text = "Tarif Dibayar:", fontSize = 10.sp, color = LakiTextMuted)
                                Text(text = formatRupiah(order.totalFare), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = LakiPrimary)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(text = "Komisi 8%:", fontSize = 10.sp, color = LakiTextMuted)
                                Text(text = formatRupiah(order.adminCommission), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = LakiSecondary)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(text = "Pendapatan Driver:", fontSize = 10.sp, color = LakiTextMuted)
                                Text(text = formatRupiah(order.driverEarnings), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Green)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminWalletAndSupportTab(viewModel: LakiViewModel, admin: Admin, orders: List<Order>) {
    var withdrawAmountStr by remember { mutableStateOf("") }
    var destinationBank by remember { mutableStateOf(admin.bankAccount) }

    val totalCommission = orders.filter { it.status == "COMPLETED" }.sumOf { it.adminCommission }

    LazyColumn(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text(text = "Wallet & Override Bantuan Admin", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = LakiTextLight)
        }

        // Wallet Balance Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = LakiSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "SALDO WALLET ADMIN ANDA", fontSize = 11.sp, color = LakiTextMuted, fontWeight = FontWeight.Bold)
                    Text(
                        text = formatRupiah(admin.walletBalance),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.Black,
                        color = LakiSecondary,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    Text(text = "Total Pendapatan Komisi Terkumpul: ${formatRupiah(totalCommission)}", fontSize = 12.sp, color = LakiTextMuted)
                }
            }
        }

        // Withdrawal form
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = LakiSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(text = "Penarikan Saldo Ke Rekening", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LakiPrimary)

                    OutlinedTextField(
                        value = withdrawAmountStr,
                        onValueChange = { withdrawAmountStr = it },
                        label = { Text("Nominal Penarikan (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = LocalTextStyle.current.copy(color = LakiTextLight)
                    )

                    OutlinedTextField(
                        value = destinationBank,
                        onValueChange = { destinationBank = it },
                        label = { Text("Nomor Rekening Tujuan") },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = LocalTextStyle.current.copy(color = LakiTextLight)
                    )

                    Button(
                        onClick = {
                            val amt = withdrawAmountStr.toDoubleOrNull() ?: 0.0
                            viewModel.withdrawAdminWallet(amt, destinationBank)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = LakiPrimary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("admin_withdraw_submit")
                    ) {
                        Text("Tarik Dana Sekarang")
                    }
                }
            }
        }

        // Help Support overrides
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = LakiSurface),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(text = "Override Akses Kendala (Bantuan)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = LakiSecondary)
                    Text(text = "Gunakan menu di bawah ini untuk membantu menyelesaikan kendala dalam pengiriman paket atau pembatalan manual oleh admin.", fontSize = 11.sp, color = LakiTextMuted, modifier = Modifier.padding(vertical = 4.dp))
                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            // Cancel latest active order for override
                            val activeOrder = orders.find { it.status != "COMPLETED" && it.status != "CANCELLED" }
                            if (activeOrder != null) {
                                viewModel.driverCancelOrder(activeOrder.id)
                                Toast.makeText(viewModel.getApplication(), "Sistem Override: Order #${activeOrder.id} dibatalkan.", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(viewModel.getApplication(), "Tidak ada orderan aktif untuk di override.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.DarkGray),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Cancel, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Batalkan Order Aktif Bermasalah")
                    }
                }
            }
        }
    }
}
